import 'package:flutter/material.dart';

class RoomScreen extends StatefulWidget {
  const RoomScreen({super.key, required this.roomName});
  final String roomName;

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  bool micRequested = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.roomName), centerTitle: true),
      body: Column(
        children: [
          const SizedBox(height: 12),
          const Text('غرفة صوتية', style: TextStyle(color: Color(0xFFC7A8FF), fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('واجهة تجريبية — الصوت المباشر يحتاج إعداد Agora'),
          const SizedBox(height: 28),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(18),
              itemCount: 12,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, mainAxisSpacing: 20, crossAxisSpacing: 12,
                childAspectRatio: .88,
              ),
              itemBuilder: (context, index) => Column(children: [
                CircleAvatar(
                  radius: 31,
                  backgroundColor: [const Color(0xFF7655C8), const Color(0xFF28778A), const Color(0xFF9B4D73)][index % 3],
                  child: Icon(index == 0 ? Icons.star_rounded : Icons.person_rounded, size: 30),
                ),
                const SizedBox(height: 7),
                Text(index == 0 ? 'المضيف' : 'مقعد ${index + 1}', style: const TextStyle(fontSize: 12)),
              ]),
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
            decoration: const BoxDecoration(color: Color(0xFF1B1729), borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _Action(icon: Icons.chat_bubble_outline_rounded, label: 'الدردشة', onTap: () {}),
              _Action(icon: Icons.card_giftcard_rounded, label: 'هدية', onTap: () {}),
              _Action(
                icon: micRequested ? Icons.mic_rounded : Icons.mic_off_rounded,
                label: micRequested ? 'إلغاء الطلب' : 'طلب المايك',
                onTap: () => setState(() => micRequested = !micRequested),
              ),
              _Action(icon: Icons.exit_to_app_rounded, label: 'خروج', onTap: () => Navigator.pop(context)),
            ]),
          ),
        ],
      ),
    );
  }
}

class _Action extends StatelessWidget {
  const _Action({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      CircleAvatar(backgroundColor: const Color(0xFF34284E), child: Icon(icon, color: const Color(0xFFD5C1FF))),
      const SizedBox(height: 6),
      Text(label, style: const TextStyle(fontSize: 11)),
    ]),
  );
}
